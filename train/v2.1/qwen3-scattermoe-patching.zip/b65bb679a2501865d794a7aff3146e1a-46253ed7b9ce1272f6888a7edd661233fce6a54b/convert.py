import transformers, torch
import configuration_qwen3_shared_moe
import modeling_qwen3_shared_moe


def convert_model(config_path: str, model_path: str):
    cfg_0 = configuration_qwen3_shared_moe.Qwen3SharedMoeConfig.from_pretrained(
        config_path
    )
    model_1 = modeling_qwen3_shared_moe.Qwen3SharedMoeForCausalLM(cfg_0)
    model_0 = transformers.AutoModelForCausalLM.from_pretrained(
        model_path, torch_dtype=torch.bfloat16
    )
    state_dict_orig = model_0.state_dict()
    # convert parameters
    with torch.no_grad():
        for n, p in model_1.named_parameters():
            assert p.dtype == torch.bfloat16
            if n in state_dict_orig:
                p.data.copy_(state_dict_orig.pop(n))
            elif "moe_mlp" in n:
                prefix, suffix = n.split("moe_mlp")
                for i in range(cfg_0.num_experts):
                    if suffix == ".output_experts.weight":
                        w2_param_name = prefix + "experts.%d.down_proj.weight" % i
                        assert state_dict_orig[w2_param_name].dtype == torch.bfloat16
                        print(f"{w2_param_name} -> {n}[{i}, :, :]")
                        p.data[i, :, :] = state_dict_orig.pop(w2_param_name)
                    else:
                        w1_param_name = prefix + "experts.%d.gate_proj.weight" % i
                        w3_param_name = prefix + "experts.%d.up_proj.weight" % i
                        out_dim, in_dim = state_dict_orig[w1_param_name].size()
                        p.data[i, :out_dim, :] = state_dict_orig.pop(w3_param_name)
                        p.data[i, out_dim:, :] = state_dict_orig.pop(w1_param_name)
                        print(f"{w3_param_name} -> {n}[{i}, :{out_dim}, :]")
                        print(f"{w1_param_name} -> {n}[{i}, {out_dim}:, :]")
            elif "shared_expert" in n:
                # no equivalent in original model, so just scale `down_proj` weights
                # down so output is ~same as original model
                if "down_proj" in n:
                    p.data *= 0.05
                continue
            else:
                raise ValueError(f"Unknown parameter {n}")
    billion_params = sum(p.numel() for p in model_1.parameters()) / 1_000_000_000
    print(f"Output model has {billion_params:.2f} billion parameters")
    return model_1


if __name__ == "__main__":
    model_out = convert_model(
        config_path="/workspace/qwen3sharedexpert/config.json",
        model_path="Qwen/Qwen3-30B-A3B-Base",
    )
    model_out.save_pretrained("/workspace/models/Qwen3-30B-A3B-SharedExpert-Base")
