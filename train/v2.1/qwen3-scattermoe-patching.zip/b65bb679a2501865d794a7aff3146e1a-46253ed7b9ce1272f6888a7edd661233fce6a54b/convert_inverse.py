import torch
import accelerate
from configuration_qwen3_shared_moe import Qwen3SharedMoeConfig
from modeling_qwen3_shared_moe import Qwen3SharedMoeForCausalLM
from transformers.models.qwen3_moe.configuration_qwen3_moe import Qwen3MoeConfig
from transformers.models.qwen3_moe.modeling_qwen3_moe import Qwen3MoeForCausalLM

def convert_shared_moe_to_standard_moe(
    shared_moe_model_path: str,
    output_model_path: str,
):
    """
    Converts a Qwen3SharedMoeForCausalLM model (with no shared expert configured)
    back to a standard Qwen3MoeForCausalLM model.
    """
    print(f"Loading Qwen3SharedMoeConfig from: {shared_moe_model_path}")
    cfg_shared_moe = Qwen3SharedMoeConfig.from_pretrained(shared_moe_model_path)

    if cfg_shared_moe.shared_expert_intermediate_size is not None:
        print(
            "Warning: The source Qwen3SharedMoeConfig has 'shared_expert_intermediate_size' set. "
            "This script assumes no shared expert is actually used or its weights will be discarded."
        )

    print("Creating standard Qwen3MoeConfig...")
    cfg_standard_moe = Qwen3MoeConfig(
        vocab_size=cfg_shared_moe.vocab_size,
        hidden_size=cfg_shared_moe.hidden_size,
        intermediate_size=cfg_shared_moe.intermediate_size,
        num_hidden_layers=cfg_shared_moe.num_hidden_layers,
        num_attention_heads=cfg_shared_moe.num_attention_heads,
        num_key_value_heads=cfg_shared_moe.num_key_value_heads,
        hidden_act=cfg_shared_moe.hidden_act,
        max_position_embeddings=cfg_shared_moe.max_position_embeddings,
        initializer_range=cfg_shared_moe.initializer_range,
        rms_norm_eps=cfg_shared_moe.rms_norm_eps,
        use_cache=cfg_shared_moe.use_cache,
        tie_word_embeddings=cfg_shared_moe.tie_word_embeddings,
        rope_theta=cfg_shared_moe.rope_theta,
        rope_scaling=cfg_shared_moe.rope_scaling,
        attention_bias=cfg_shared_moe.attention_bias,
        use_sliding_window=cfg_shared_moe.use_sliding_window,
        sliding_window=cfg_shared_moe.sliding_window,
        max_window_layers=cfg_shared_moe.max_window_layers,
        attention_dropout=cfg_shared_moe.attention_dropout,
        decoder_sparse_step=cfg_shared_moe.decoder_sparse_step,
        moe_intermediate_size=cfg_shared_moe.moe_intermediate_size,
        num_experts_per_tok=cfg_shared_moe.num_experts_per_tok,
        num_experts=cfg_shared_moe.num_experts,
        norm_topk_prob=cfg_shared_moe.norm_topk_prob,
        output_router_logits=cfg_shared_moe.output_router_logits,
        router_aux_loss_coef=cfg_shared_moe.router_aux_loss_coef,
        mlp_only_layers=cfg_shared_moe.mlp_only_layers,
    )

    print(f"Loading Qwen3SharedMoeForCausalLM model from: {shared_moe_model_path}")
    model_shared_moe = Qwen3SharedMoeForCausalLM.from_pretrained(
        shared_moe_model_path,
        torch_dtype=torch.bfloat16,
        low_cpu_mem_usage=True
    )
    state_dict_shared_moe = model_shared_moe.state_dict()
    
    print("Instantiating standard Qwen3MoeForCausalLM model...")
    with accelerate.init_empty_weights():
        model_standard_moe = Qwen3MoeForCausalLM(cfg_standard_moe)
    
    model_standard_moe = model_standard_moe.to(torch.bfloat16)
    new_state_dict = {}
    processed_shared_keys = set()

    print("Converting state dictionary...")
    for name_shared, param_shared in state_dict_shared_moe.items():
        if name_shared in processed_shared_keys:
            continue

        if "shared_expert" in name_shared:
            print(f"  Discarding shared_expert parameter: {name_shared}")
            processed_shared_keys.add(name_shared)
            continue

        # Handle scattermoe's GLUMLP weights for MoE layers
        # scattermoe: layers.X.mlp.moe_mlp.output_experts.weight
        # standard HF: layers.X.mlp.experts.<i>.down_proj.weight
        if "mlp.moe_mlp.output_experts.weight" in name_shared:
            prefix = name_shared.split("mlp.moe_mlp.output_experts.weight")[0]
            for i in range(cfg_shared_moe.num_experts):
                target_name = f"{prefix}mlp.experts.{i}.down_proj.weight"
                new_state_dict[target_name] = param_shared[i, :, :].clone()
                print(f"  Converted: {name_shared}[{i},:,:] -> {target_name}")
            processed_shared_keys.add(name_shared)
        # scattermoe: layers.X.mlp.moe_mlp.experts.weight (contains concatenated up_proj and gate_proj)
        # standard HF: layers.X.mlp.experts.<i>.up_proj.weight and layers.X.mlp.experts.<i>.gate_proj.weight
        elif "mlp.moe_mlp.experts.weight" in name_shared:
            prefix = name_shared.split("mlp.moe_mlp.experts.weight")[0]
            # This is the intermediate size of one part of the GLU (e.g., up_proj output dim)
            moe_glu_intermediate_size = cfg_shared_moe.moe_intermediate_size
            for i in range(cfg_shared_moe.num_experts):
                target_up_proj_name = f"{prefix}mlp.experts.{i}.up_proj.weight"
                target_gate_proj_name = f"{prefix}mlp.experts.{i}.gate_proj.weight"
                
                # param_shared shape: [num_experts, 2 * moe_glu_intermediate_size, hidden_size_in]
                new_state_dict[target_up_proj_name] = param_shared[i, :moe_glu_intermediate_size, :].clone()
                new_state_dict[target_gate_proj_name] = param_shared[i, moe_glu_intermediate_size:, :].clone()
                print(f"  Converted: {name_shared}[{i},:{moe_glu_intermediate_size},:] -> {target_up_proj_name}")
                print(f"  Converted: {name_shared}[{i},{moe_glu_intermediate_size}:,:] -> {target_gate_proj_name}")
            processed_shared_keys.add(name_shared)
        # Direct copy for all other parameters (attention, layernorms, embeddings, non-MoE MLPs, MoE router gate)
        else:
            if name_shared not in new_state_dict:
                if name_shared in model_standard_moe.state_dict():
                    new_state_dict[name_shared] = param_shared.clone()
                else:
                    print(f"  Warning: Parameter {name_shared} from source model not found in target standard model structure. Discarding.")
            processed_shared_keys.add(name_shared)

    # Sanity checks
    target_model_keys = set(model_standard_moe.state_dict().keys())
    converted_keys = set(new_state_dict.keys())

    missing_keys = target_model_keys - converted_keys
    if missing_keys:
        print(f"Error: The following keys are expected by the standard model but were not generated: {missing_keys}")
    
    extra_keys = converted_keys - target_model_keys
    if extra_keys:
        print(f"Warning: The following keys were generated but are not expected by the standard model: {extra_keys}")

    print("Loading converted state dictionary into standard model...")
    model_standard_moe.load_state_dict(new_state_dict, strict=True)

    print(f"Saving standard Qwen3MoeForCausalLM model to: {output_model_path}")
    model_standard_moe.save_pretrained(output_model_path)
    cfg_standard_moe.save_pretrained(output_model_path)

    billion_params_shared = sum(p.numel() for p in model_shared_moe.parameters()) / 1_000_000_000
    billion_params_standard = sum(p.numel() for p in model_standard_moe.parameters()) / 1_000_000_000
    print(f"Source Qwen3SharedMoe model parameters: {billion_params_shared:.2f}B")
    print(f"Converted standard Qwen3Moe model parameters: {billion_params_standard:.2f}B")
    print("Conversion complete.")
    return model_standard_moe
